# 3D Kalkulačka P2S – opravená verze 0.2

Samostatná desktopová aplikace **Python + Qt (PySide6)** pro Bambu Studio a MX Linux KDE. Běží offline, bez webhostingu a bez připojení k tiskárně.

## Instalace na MX Linux KDE

Rozbal celý ZIP do vybrané složky. Otevři terminál **v této složce** a spusť (jednorázově):

```bash
sudo apt install python3-venv kdialog
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

`kdialog` slouží k otevření **nativního dialogu KDE s korektní českou diakritikou**. Je doporučený, ale nepovinný: pokud chybí, aplikace použije Qt dialog s českými popisky.

**Přechod z verze 0.1:** staré soubory programu můžeš přepsat novými soubory ZIP. Složku `.venv` nemaž – obsahuje knihovnu PySide6 a není potřeba ji instalovat znovu. Tvoje nastavení v `~/.config/3d-kalkulacka-p2s/settings.json` i uložené zakázky zůstávají použitelné.

Potom aplikaci kdykoliv spustíš dvojklikem na `spustit.sh` (volba „Spustit“), nebo příkazem:

```bash
./spustit.sh
```

Případně přímo: `.venv/bin/python app.py`. Instalace knihovny PySide6 potřebuje internet; aplikace samotná už ne.

## Jak vyzkoušet

1. Spusť `./spustit.sh`.
2. Klikni na **+ Přidat G-code** a vyber například svůj `Oci.gcode.3mf` (výstup z naslicované podložky Bambu Studia). Soubor lze i přetáhnout do okna.
3. V tabulce uvidíš jednotlivé tisky, vpravo detail, náhled, barevný pruh spotřeby filamentů a cenovou kalkulaci.
4. **Výběr jiného filamentu:** vpravo v tabulce filamentů klikni do sloupce **Materiál / ceník** a rozbal seznam. Můžeš zvolit běžný typ (PLA, PETG, TPU, ...) nebo konkrétní vlastní filament z ceníku, jehož cena se doplní automaticky. **Kč/kg** lze stále upravit ručně.
5. **Vlastní ceník:** v **Nastavení → Ceník vlastních filamentů** klikni na „+ Přidat materiál“. Zadej například název `Bambu PLA Basic – černá`, typ `PLA`, barvu `#161616` (nepovinná) a cenu `320`. Další řádek může mít úplně stejný typ i barvu, ale jiný **název a cenu**. Po potvrzení se obě položky objeví v rozbalovací nabídce materiálů. Barva zadaná v ceníku případně upraví vzorník vybraného filamentu.
6. **Motivy:** v **Nastavení → Motiv aplikace** vyber tmavý, světlý, kombinovaný (tmavé pozadí / světlé panely) nebo barevný motiv.
7. Pak můžeš uložit zakázku (`*.3dk.json`) a exportovat PDF nebo CSV.
6. **Otevřít** → `Ukazka_Oci.3dk.json` zobrazí předpřipravený demonstrační výpočet bez potřeby znovu vybírat G-code.

## Funkce

- Načítání více `.gcode.3mf`/`.gcode`/`.gco` souborů, včetně celé složky (rekurzivně, do 500 souborů).
- Čas tisku ze sliceru, spotřeba po jednotlivých barvách a typech filamentu, modely na podložce a náhled z 3MF.
- **Neúčtuje nepoužité profily** (u demonstrace je na podložce pouze 3× PLA, i když projekt obsahuje 4. nastavený PETG).
- Pojmenované položky ceníku s volbou konkrétního filamentu přímo na každé řádce; různé ceny i pro stejný typ/barvu. Opravy lze zadat ručně.
- Výběr účtování elektřiny: pevná sazba za hodinu nebo cena kWh × průměrný příkon.
- Amortizace, ruční práce, další náklady, počet kusů, koeficient pro každý tisk a celou zakázku.
- Uložení a znovuotevření zakázky i s upravenými cenami a thumbnail obrázky.
- PDF report, CSV export, čtyři motivy, výrazné orámování tabulek a viditelné šipky/posuvníky.

## Výchozí hodnoty a uložení

Z `basic.php` převzato: **amortizace 10 Kč/h, energie 2 Kč/h, filament 200 Kč/kg, koeficient 1,5**.

Výchozí hodnoty jsou jen **startovní** a lze je měnit. Aplikace nijak nepoužívá hodnotu `filament_cost` z Bambu Studia (nemusí být v Kč). Je lepší spravovat vlastní cenový katalog. Bambu Studio poskytuje především **čas a množství**.

Nastavení se ukládá do: `~/.config/3d-kalkulacka-p2s/settings.json`.
Zakázky se ukládají na místo, které si vybereš, ve formátu `*.3dk.json`. Každá zakázka uchovává i své sazby.

## Omezení této verze

- **Čas a spotřeba jsou převzaty z Bambu Studia, nikoli z měření skutečného tisku.** Pokud chybí, lze čas, materiál i hmotnost zadat ručně.
- Spotřeba z exportu sliceru je účtována **tak, jak ji export uvádí**. Odpad z AMS se nepřičítá podruhé; rozdělení odpadu na očištění/věž/model zatím není samostatně doložené.
- Více modelů naslicovaných na **jedné podložce** je považováno za jeden tisk. Rozdělit jeho čas mezi jednotlivé modely by bez dalších údajů nebylo správné.
- Pokud načteš několik tisků, jejich časy se sčítají. Nejde o plánování souběžného tisku.
- U jednotlivého `.gcode` bez informací sliceru může být nutné hodnoty vyplnit ručně.
- PDF je tiskový rozpočet, **nikoliv daňová faktura**.

## Kontrola výpočtů

Samostatnou čtečku a výpočty lze otestovat bez PySide6:

```bash
python3 test_engine.py
```

Testy zahrnují výpočet ceny, katalog barev, ukládání zakázek, kompatibilitu předchozího formátu, čtení archivů a obyčejný G-code.

**Poznámka k ověření:** Výpočetní část byla otestována na dodaném `Oci.gcode.3mf`. Grafické prostředí nebylo v prostředí tvorby možné přímo spustit kvůli nedostupnému PySide6. Změny rozhraní jsou kontrolované staticky a syntaxe je ověřena, ale vzhled bude potřeba finálně ověřit při spuštění na MX Linuxu.
