"""Datový model a čtečka Bambu Studio G-code / .gcode.3mf (bez dalších knihoven)."""
from __future__ import annotations

import base64
import json
import re
import uuid
import zipfile
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

APP_VERSION = '0.2.0'
PROJECT_EXT = '.3dk.json'


def float_or(value: Any, default: float = 0.0) -> float:
    try:
        return float(str(value).strip().replace(',', '.'))
    except (TypeError, ValueError):
        return default


def safe_hex(value: str) -> str:
    value = (value or '').strip().upper()
    return value if re.fullmatch(r'#[A-F0-9]{6}', value) else '#737D91'


def color_name(value: str) -> str:
    """Zjednodušené české názvy barev; odstín zůstává uložen v HEX."""
    import colorsys
    value = safe_hex(value)
    r, g, b = (int(value[i:i+2], 16) / 255 for i in (1, 3, 5))
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    if v < .18: return 'Černá'
    if s < .13:
        if v > .90: return 'Bílá'
        return 'Šedá'
    hue = h * 360
    if hue < 15 or hue >= 345: return 'Červená'
    if hue < 43: return 'Oranžová'
    if hue < 71: return 'Žlutá'
    if hue < 168: return 'Zelená'
    if hue < 200: return 'Tyrkysová'
    if hue < 254: return 'Modrá'
    if hue < 291: return 'Fialová'
    if hue < 345: return 'Růžová'
    return 'Jiná'


def human_duration(seconds: float) -> str:
    s = max(0, int(round(seconds)))
    h, r = divmod(s, 3600)
    m, sec = divmod(r, 60)
    if h: return f'{h} h {m:02d} min'
    if m: return f'{m} min {sec:02d} s'
    return f'{sec} s'


def money(n: float) -> str:
    return f'{n:,.2f}'.replace(',', ' ').replace('.', ',') + ' Kč'


@dataclass
class Rates:
    printer_name: str = 'Bambu Lab P2S'
    amortization_per_hour: float = 10.0
    energy_mode: str = 'hourly'  # 'hourly' nebo 'power'
    energy_per_hour: float = 2.0
    power_watt: float = 100.0
    price_kwh: float = 6.0
    default_price_kg: float = 200.0
    default_coefficient: float = 1.5
    manual_hour_rate: float = 0.0
    catalog: list[dict[str, Any]] = field(default_factory=list)
    dark_mode: bool = True  # kompatibilita s v0.1
    theme: str = ''  # prázdné = převzít starou volbu dark_mode

    def __post_init__(self):
        # Převod staršího ceníku bez pojmenování na jednoznačné položky.
        # Díky tomu se v nabídce rozlišují i dva filamenty stejného typu.
        used: set[tuple[str, str]] = set()
        for entry in self.catalog:
            typ = str(entry.get('material', '')).strip() or 'Materiál'
            color = str(entry.get('color', '')).strip()
            base = str(entry.get('name', '')).strip()
            if not base:
                base = typ + (' – ' + color_name(color) if color else ' – obecný')
            name = base
            n = 2
            while (typ.casefold(), name.casefold()) in used:
                name = f'{base} ({n})'
                n += 1
            entry['name'] = name
            used.add((typ.casefold(), name.casefold()))

    def theme_name(self) -> str:
        return self.theme if self.theme in ('dark', 'light', 'hybrid', 'color') else ('dark' if self.dark_mode else 'light')

    def hourly_energy_cost(self) -> float:
        if self.energy_mode == 'power':
            return self.power_watt / 1000 * self.price_kwh
        return self.energy_per_hour

    def lookup_price(self, material: str, color: str) -> float:
        material = material.strip().casefold()
        color = safe_hex(color)
        for item in self.catalog:
            if str(item.get('material', '')).strip().casefold() == material and safe_hex(item.get('color', '')) == color and item.get('color', ''):
                return float_or(item.get('price_kg'), self.default_price_kg)
        for item in self.catalog:
            if str(item.get('material', '')).strip().casefold() == material and not item.get('color', ''):
                return float_or(item.get('price_kg'), self.default_price_kg)
        return self.default_price_kg


@dataclass
class Filament:
    slot: int
    material: str
    color: str
    grams: float
    meters: float = 0.0
    price_kg: float = 200.0
    profile: str = ''
    catalog_name: str = ''  # volitelná výslovně zvolená položka ceníku

    @property
    def cost(self) -> float:
        return max(0.0, self.grams) * max(0.0, self.price_kg) / 1000


@dataclass
class PrintJob:
    id: str
    name: str
    path: str
    plate: int
    objects: list[str]
    time_seconds: float
    filaments: list[Filament]
    printer: str = ''
    nozzle: str = ''
    layer_height: str = ''
    layers: int = 0
    switches: int = 0
    thumbnail_b64: str = ''
    warnings: list[str] = field(default_factory=list)
    quantity: int = 1
    coefficient: float = 1.5
    extra_cost: float = 0.0
    labor_minutes: float = 0.0
    model_time_seconds: float = 0.0

    def totals(self, rates: Rates) -> dict[str, float]:
        qty = max(1, self.quantity)
        hours = max(0.0, self.time_seconds) / 3600
        material = sum(f.cost for f in self.filaments)
        amort = hours * rates.amortization_per_hour
        energy = hours * rates.hourly_energy_cost()
        labor = max(0.0, self.labor_minutes) / 60 * rates.manual_hour_rate
        extra = max(0.0, self.extra_cost)
        base = material + amort + energy + labor + extra
        unit_price = base * max(1.0, self.coefficient)
        return dict(grams=sum(max(0.0, f.grams) for f in self.filaments) * qty,
                    seconds=max(0.0, self.time_seconds) * qty,
                    material=material * qty, amort=amort * qty,
                    energy=energy * qty, labor=labor * qty, extra=extra * qty,
                    base=base * qty, price=unit_price * qty,
                    unit_base=base, unit_price=unit_price)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, obj: dict[str, Any]) -> 'PrintJob':
        allowed = {f.name for f in fields(cls)}
        values = {k: v for k, v in obj.items() if k in allowed}
        values['filaments'] = [Filament(**{k: v for k, v in f.items() if k in {x.name for x in fields(Filament)}})
                               for f in obj.get('filaments', [])]
        return cls(**values)


def default_config_path() -> Path:
    return Path.home() / '.config' / '3d-kalkulacka-p2s' / 'settings.json'


def load_rates() -> Rates:
    path = default_config_path()
    if not path.exists(): return Rates()
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        return Rates(**{key: value for key, value in data.items() if key in {f.name for f in fields(Rates)}})
    except (ValueError, OSError, TypeError):
        return Rates()


def save_rates(rates: Rates) -> None:
    path = default_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(asdict(rates), ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def save_project(path: str | Path, title: str, rates: Rates, jobs: list[PrintJob]) -> None:
    data = {'format': '3dk-p2s', 'version': 1, 'saved_at': datetime.now().isoformat(timespec='seconds'),
            'title': title, 'rates': asdict(rates), 'jobs': [j.to_dict() for j in jobs]}
    p = Path(path)
    tmp = p.with_name(p.name + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(p)


def open_project(path: str | Path) -> tuple[str, Rates, list[PrintJob]]:
    obj = json.loads(Path(path).read_text(encoding='utf-8'))
    if obj.get('format') != '3dk-p2s' or obj.get('version') != 1:
        raise ValueError('Neznámý formát souboru zakázky.')
    rates = Rates(**{k: v for k, v in obj['rates'].items() if k in {f.name for f in fields(Rates)}})
    return obj.get('title', 'Nová zakázka'), rates, [PrintJob.from_dict(j) for j in obj.get('jobs', [])]


def _gcode_header(text: str) -> dict[str, Any]:
    def get_list(pattern: str) -> list[str]:
        m = re.search(pattern, text, flags=re.I | re.M)
        if not m: return []
        return [x.strip().strip('"') for x in re.split(r'[;,]', m.group(1)) if x.strip()]

    data: dict[str, Any] = {}
    line = re.search(r';\s*model printing time:\s*([^;\r\n]+);\s*total estimated time:\s*([^;\r\n]+)', text, re.I)
    if line:
        data['model_time'] = _parse_duration(line.group(1))
        data['time'] = _parse_duration(line.group(2))
    # Starší Bambu/Prusa profily mohou zapisovat přímo sekundy.
    if not data.get('time'):
        m = re.search(r';\s*estimated printing time[^:\n]*:\s*(\d+h[^\r\n]*|\d+m[^\r\n]*|\d+s)', text, re.I)
        if m: data['time'] = _parse_duration(m.group(1))
    data['weights'] = [float_or(v) for v in get_list(r';\s*total filament weight \[g\]\s*:\s*([^\r\n]+)')]
    data['meters'] = [float_or(v) / 1000 for v in get_list(r';\s*total filament length \[mm\]\s*:\s*([^\r\n]+)')]
    # Bambu komentáře: barevné profily mohou být v hlavičce i na konci.
    data['types'] = get_list(r';\s*filament_type\s*=\s*([^\r\n]+)')
    data['colors'] = get_list(r';\s*filament_colour\s*=\s*([^\r\n]+)')
    m = re.search(r';\s*total layer number:\s*(\d+)', text, re.I)
    data['layers'] = int(m.group(1)) if m else 0
    m = re.search(r';\s*layer_height\s*=\s*([0-9.,]+)', text, re.I)
    data['layer_height'] = m.group(1) if m else ''
    return data


def _parse_duration(text: str) -> float:
    secs = 0
    for num, unit in re.findall(r'(\d+(?:[.,]\d+)?)\s*([hms])\b', text, flags=re.I):
        secs += float_or(num) * {'h': 3600, 'm': 60, 's': 1}[unit.lower()]
    return secs


def _get_zip_head(z: zipfile.ZipFile, name: str, limit: int = 1_500_000) -> str:
    with z.open(name) as f:
        return f.read(limit).decode('utf-8-sig', 'replace')


def _xml_meta(node: ET.Element) -> dict[str, str]:
    return {child.attrib.get('key', ''): child.attrib.get('value', '')
            for child in node.findall('./metadata')}


def _project_settings(z: zipfile.ZipFile) -> dict[str, Any]:
    name = 'Metadata/project_settings.config'
    if name not in z.namelist(): return {}
    try:
        raw = z.read(name)
        if len(raw) > 4_000_000: return {}
        return json.loads(raw.decode('utf-8-sig'))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return {}


def _filament_profiles(settings: dict[str, Any]) -> list[str]:
    candidates = settings.get('filament_settings_id') or []
    return candidates if isinstance(candidates, list) else []


def _make_filaments(plate: ET.Element | None, meta: dict[str, Any], settings: dict[str, Any], rates: Rates) -> list[Filament]:
    out = []
    profiles = _filament_profiles(settings)
    if plate is not None:
        for el in plate.findall('filament'):
            grams = float_or(el.attrib.get('used_g'))
            if grams <= 0: continue  # Profil připravený, ale nepoužitý.
            slot = int(el.attrib.get('id', len(out) + 1))
            material = el.attrib.get('type', 'Neurčeno') or 'Neurčeno'
            color = safe_hex(el.attrib.get('color', ''))
            profile = profiles[slot - 1] if 0 < slot <= len(profiles) else ''
            out.append(Filament(slot, material, color, grams, float_or(el.attrib.get('used_m')),
                                rates.lookup_price(material, color), profile))
    if out: return out
    types = meta.get('types') or settings.get('filament_type') or []
    colors = meta.get('colors') or settings.get('filament_colour') or []
    weights = meta.get('weights') or []
    if not isinstance(types, list): types = []
    if not isinstance(colors, list): colors = []
    for i, grams in enumerate(weights):
        if grams <= 0: continue
        material = types[i] if i < len(types) else 'Neurčeno'
        color = safe_hex(colors[i] if i < len(colors) else '')
        out.append(Filament(i + 1, material, color, grams,
                            (meta.get('meters') or [])[i] if i < len(meta.get('meters') or []) else 0,
                            rates.lookup_price(material, color), profiles[i] if i < len(profiles) else ''))
    return out


def _sequence_switches(z: zipfile.ZipFile, plate: int) -> int:
    try:
        data = json.loads(z.read('Metadata/filament_sequence.json'))
        seq = data.get(f'plate_{plate}', {}).get('sequence', [])
        return sum(seq[i] != seq[i-1] for i in range(1, len(seq)))
    except (KeyError, ValueError, TypeError): return 0


def parse_3mf(path: str | Path, rates: Rates) -> list[PrintJob]:
    path = Path(path)
    with zipfile.ZipFile(path) as z:
        if 'Metadata/slice_info.config' not in z.namelist() and not any(re.fullmatch(r'Metadata/plate_\d+\.gcode', n) for n in z.namelist()):
            raise ValueError('Soubor neobsahuje naslicované G-code. V Bambu Studiu použij Export plate sliced file (.gcode.3mf).')
        plates: list[ET.Element] = []
        if 'Metadata/slice_info.config' in z.namelist():
            xml = z.read('Metadata/slice_info.config')
            plates = ET.fromstring(xml).findall('plate')
        lookup: dict[int, ET.Element] = {}
        for i, plate in enumerate(plates, start=1):
            info = _xml_meta(plate)
            idx = int(info.get('index', i))
            lookup[idx] = plate
        if not lookup:
            indices = [int(re.search(r'plate_(\d+)\.gcode', name).group(1)) for name in z.namelist() if re.fullmatch(r'Metadata/plate_\d+\.gcode', name)]
            lookup = {idx: None for idx in indices}
        project_settings = _project_settings(z)
        result = []
        for plate_num, plate in sorted(lookup.items()):
            info = _xml_meta(plate) if plate is not None else {}
            gname = f'Metadata/plate_{plate_num}.gcode'
            if gname not in z.namelist(): continue
            header = _gcode_header(_get_zip_head(z, gname))
            seconds = float_or(info.get('prediction')) or header.get('time', 0)
            filaments = _make_filaments(plate, header, project_settings, rates)
            weight = float_or(info.get('weight'))
            notes = []
            if not filaments and weight > 0:
                filaments = [Filament(1, 'Neurčeno', '#737D91', weight, price_kg=rates.default_price_kg)]
                notes.append('Typ a barvu filamentu se nepodařilo určit. Zkontroluj je ručně.')
            if not filaments: notes.append('Ve zdrojovém souboru nebyla nalezena spotřeba filamentu. Doplň ji ručně.')
            if not seconds: notes.append('V souboru není odhad času tisku. Doplň jej ručně.')
            if weight and filaments and abs(sum(f.grams for f in filaments) - weight) > max(.5, weight * .05):
                notes.append('Součet hmotností filamentů se liší od celkového údaje sliceru. Ověř spotřebu.')
            names = [el.attrib.get('name', '') for el in plate.findall('object')] if plate is not None else []
            names = [n for n in names if n]
            thumb_name = f'Metadata/plate_{plate_num}_small.png'
            if thumb_name not in z.namelist(): thumb_name = f'Metadata/plate_{plate_num}.png'
            thumb = ''
            if thumb_name in z.namelist() and z.getinfo(thumb_name).file_size < 2_000_000:
                thumb = base64.b64encode(z.read(thumb_name)).decode('ascii')
            nm = re.sub(r'\.gcode\.3mf$|\.3mf$', '', path.name, flags=re.I)
            if len(lookup) > 1: nm += f' – podložka {plate_num}'
            result.append(PrintJob(
                id=uuid.uuid4().hex, name=nm, path=str(path), plate=plate_num, objects=names,
                time_seconds=seconds, filaments=filaments, printer=rates.printer_name,
                nozzle=info.get('nozzle_diameters') or header.get('nozzle', ''),
                layer_height=str(project_settings.get('layer_height') or header.get('layer_height') or ''),
                layers=header.get('layers', 0), switches=_sequence_switches(z, plate_num),
                thumbnail_b64=thumb, warnings=notes, coefficient=rates.default_coefficient,
                model_time_seconds=header.get('model_time', 0)))
        if not result: raise ValueError('V archivu není žádná podložka s tiskovým G-codem.')
        return result


def parse_plain_gcode(path: str | Path, rates: Rates) -> list[PrintJob]:
    path = Path(path)
    with path.open('rb') as f:
        head = f.read(1_500_000)
        if path.stat().st_size > 1_500_000:
            f.seek(max(0, path.stat().st_size - 500_000))
            tail = f.read(500_000)
        else:
            tail = b''
    meta = _gcode_header(head.decode('utf-8-sig', 'replace') + '\n' + tail.decode('utf-8', 'replace'))
    filaments = _make_filaments(None, meta, {}, rates)
    seconds = meta.get('time', 0)
    warnings = []
    if not seconds: warnings.append('G-code neobsahuje odhad tiskového času. Doplň jej ručně.')
    if not filaments: warnings.append('G-code neobsahuje spotřebu filamentu. Doplň ji ručně.')
    return [PrintJob(id=uuid.uuid4().hex, name=path.stem, path=str(path), plate=1, objects=[],
                     time_seconds=seconds, filaments=filaments, printer=rates.printer_name,
                     layer_height=meta.get('layer_height', ''), layers=meta.get('layers', 0),
                     model_time_seconds=meta.get('model_time', 0),
                     warnings=warnings, coefficient=rates.default_coefficient)]


def parse_file(path: str | Path, rates: Rates) -> list[PrintJob]:
    path = Path(path)
    if not path.is_file(): raise FileNotFoundError(path)
    if path.name.lower().endswith(('.gcode.3mf', '.3mf')):
        return parse_3mf(path, rates)
    if path.name.lower().endswith(('.gcode', '.gco')):
        return parse_plain_gcode(path, rates)
    raise ValueError('Podporované soubory: .gcode.3mf, .gcode, .gco')


def project_totals(jobs: list[PrintJob], rates: Rates) -> dict[str, float]:
    keys = ('grams', 'seconds', 'material', 'amort', 'energy', 'labor', 'extra', 'base', 'price')
    return {key: sum(job.totals(rates)[key] for job in jobs) for key in keys}
