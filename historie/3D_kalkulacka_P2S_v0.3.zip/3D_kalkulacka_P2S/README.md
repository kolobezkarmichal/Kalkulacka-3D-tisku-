# 3D Kalkulačka P2S – verze 0.3

Samostatná **offline aplikace v Pythonu / PySide6** pro MX Linux KDE. Navazuje na v0.2 a zachovává hromadné načítání `.gcode.3mf`, náhledy modelů, barevné filamenty, ukládání zakázek i PDF/CSV export.

## Aktualizace z v0.2

1. **Zálohuj si** pro jistotu původní aplikaci a soubor `~/.config/3d-kalkulacka-p2s/settings.json`.
2. Rozbal ZIP a nahraď staré soubory kalkulačky soubory z nové složky `3D_kalkulacka_P2S`.
3. **Nemaž `.venv`**: dosavadní instalace PySide6 může zůstat zachovaná.
4. Spusť `./spustit.sh`.

Nová instalace, pokud Python prostředí ještě nemáš:

```bash
sudo apt install python3-venv kdialog
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
./spustit.sh
```

## Novinka: pevná cena

1. Načti G-code a označ tisk vlevo.
2. Vpravo v **Parametry a nacenění → Způsob nacenění** přepni na **Pevná výsledná cena**.
3. Do **Pevná cena za jeden tisk** zadej požadovanou částku v Kč. Při prvním přepnutí se navrhne dosavadní cena podle koeficientu.
4. Počet tisků se násobí: **150 Kč/tisk × 3 kusy = 450 Kč**. Pro návrat zvol **Koeficient × náklady**.

V rozpisu ceny vidíš rozdíl `výsledná cena − náklady` (může být záporný). Režim se uloží spolu se zakázkou a uvede do PDF/CSV exportu.

## Novinka: CSV sklad filamentů

1. V hlavním okně klikni **Import skladu** nebo v **Nastavení → Ceník a sklad vlastních filamentů → Importovat CSV s filamenty**.
2. Vyber export ze své evidence filamentů, např. přibalený `prehled-filamentu-2026-11-21.csv`.
3. Program rozpozná sloupce `ID`, `Název / barva`, `Materiál`, `Výrobce`, `Množství (g)`, případně `Datum změny` a `Viditelnost`. Importuje i skryté nebo vyprodané položky.
4. V **Nastavení → Ceník a sklad** doplň ceny (sloupec **Cena Kč/kg**) u materiálů, které ještě nejsou naceněné. Cena je **za kilogram**, nikoli za celou cívku. Políčko **HEX** je nepovinné; export neobsahuje HEX kódy barev, proto se z něj přesná barva automaticky neurčuje.
5. Potvrď **OK** pro uložení změn nastavení.
6. Načti G-code, u filamentu rozbal **Materiál / ceník** a vyber přesnou skladovou položku podle názvu a výrobce. Aplikace použije její cenu a doplní **Zbývá po zakázce**. Bez stanovené ceny zůstává viditelně označená výchozí sazba.

**Automatická cena:** U výrobce `3D FOX` s označením `Přeběh` v názvu/popisu je po importu **200 Kč/kg**. Pokud v nastavení zadáš vlastní cenu, další import ji respektuje. V dodaném CSV jsou čtyři takové položky.

**Aktualizace:** Pozdější export CSV můžeš opět importovat. Identifikace probíhá podle **ID**, aktualizují se skladové zásoby a údaje o položce, ale **už nastavené ceny se zachovávají**. Položky, které v novém CSV chybí, automaticky nemažeme – aby se nevymazala tvoje historie nebo ceny. Je možné je odebrat ručně.

### Jak funguje kontrola zásob

- Ve sloupci **Zbývá po zakázce** se zobrazí `množství v CSV − součet spotřeby přiřazeného filamentu × počty kusů` napříč celou otevřenou zakázkou.
- Když požadovaná spotřeba přesáhne zásobu, objeví se **upozornění na nedostatek** a záporný zůstatek.
- Jde o **plán**, nikoliv automatický odpis ze skladu. Samotná kalkulačka nemění CSV ani evidenci, která je jeho zdrojem.
- V přepočtech se vychází ze spotřeby uváděné Bambu Studiem; pokud není dostupná, spotřebu je možné upravit ručně.

## Co je v ZIP

- `app.py` – desktopové rozhraní
- `engine.py` – výpočty, čtení G-code a import CSV
- `requirements.txt`, `spustit.sh`, `assets/` – spuštění a vzhled
- `Ukazka_Oci.3dk.json` – ukázková zakázka ze starší verze
- `prehled-filamentu-2026-11-21.csv` – kopie poskytnutého exportu pro okamžité vyzkoušení
- `test_engine.py`, `test_inventory.py` – automatické testy

## Testování a omezení

Testy bez PySide6 spustíš pomocí:

```bash
python3 test_engine.py
python3 test_inventory.py
```

**Výpočty a CSV byly otestované**, grafické okno však nebylo možné v pracovním prostředí přímo spustit bez PySide6. Vzhled a klikání je třeba potvrdit na počítači s MX Linuxem.

Důležité: pevná cena je *za jeden tisk celé podložky*, ne za jednotlivé modely na téže podložce. Cena filamentu bez vyplněné ceníkové částky dočasně používá výchozí Kč/kg a zobrazuje na to upozornění. V běžném `.gcode` bez metadat mohou některé údaje chybět.
