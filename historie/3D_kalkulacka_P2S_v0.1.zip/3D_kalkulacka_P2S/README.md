# 3D Kalkulačka P2S – první verze (0.1)

Samostatná desktopová aplikace **Python + Qt (PySide6)** pro Bambu Studio a MX Linux KDE. Běží offline, bez webhostingu a bez připojení k tiskárně.

## Instalace na MX Linux KDE

Rozbal celý ZIP do vybrané složky. Otevři terminál **v této složce** a spusť (jednorázově):

```bash
sudo apt install python3-venv
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

Potom aplikaci kdykoliv spustíš dvojklikem na `spustit.sh` (volba „Spustit“), nebo příkazem:

```bash
./spustit.sh
```

Případně přímo: `.venv/bin/python app.py`. Instalace knihovny PySide6 potřebuje internet; aplikace samotná už ne.

## Jak vyzkoušet

1. Spusť `./spustit.sh`.
2. Klikni na **+ Přidat G-code** a vyber například svůj `Oci.gcode.3mf` (výstup z naslicované podložky Bambu Studia). Soubor lze i přetáhnout do okna.
3. V tabulce uvidíš jednotlivé tisky, vpravo detail, náhled, barevný pruh spotřeby filamentů a cenovou kalkulaci.
4. Změň cenu/kg, počet kusů, koeficient nebo cenu dalších nákladů. Všechno se okamžitě přepočítá.
5. V **Nastavení** uprav sazby a ceník. Pak můžeš uložit zakázku (`*.3dk.json`) a exportovat PDF nebo CSV.
6. **Otevřít** → `Ukazka_Oci.3dk.json` zobrazí předpřipravený demonstrační výpočet bez potřeby znovu vybírat G-code.

## Funkce

- Načítání více `.gcode.3mf`/`.gcode`/`.gco` souborů, včetně celé složky (rekurzivně, do 500 souborů).
- Čas tisku ze sliceru, spotřeba po jednotlivých barvách a typech filamentu, modely na podložce a náhled z 3MF.
- **Neúčtuje nepoužité profily** (u demonstrace je na podložce pouze 3× PLA, i když projekt obsahuje 4. nastavený PETG).
- Ceník filamentů podle materiálu i HEX barvy a případné ruční úpravy pro konkrétní tisk.
- Výběr účtování elektřiny: pevná sazba za hodinu nebo cena kWh × průměrný příkon.
- Amortizace, ruční práce, další náklady, počet kusů, koeficient pro každý tisk a celou zakázku.
- Uložení a znovuotevření zakázky i s upravenými cenami a thumbnail obrázky.
- PDF report, CSV export, automatický tmavý vzhled (lze změnit v Nastavení).

## Výchozí hodnoty a uložení

Z `basic.php` převzato: **amortizace 10 Kč/h, energie 2 Kč/h, filament 200 Kč/kg, koeficient 1,5**.

Výchozí hodnoty jsou jen **startovní** a lze je měnit. Aplikace nijak nepoužívá hodnotu `filament_cost` z Bambu Studia (nemusí být v Kč). Je lepší spravovat vlastní cenový katalog. Bambu Studio poskytuje především **čas a množství**.

Nastavení se ukládá do: `~/.config/3d-kalkulacka-p2s/settings.json`.
Zakázky se ukládají na místo, které si vybereš, ve formátu `*.3dk.json`. Každá zakázka uchovává i své sazby.

## Omezení první verze

- **Čas a spotřeba jsou převzaty z Bambu Studia, nikoli z měření skutečného tisku.** Pokud chybí, lze čas, materiál i hmotnost zadat ručně.
- Spotřeba z exportu sliceru je účtována **tak, jak ji export uvádí**. Odpad z AMS se nepřičítá podruhé; rozdělení odpadu na očištění/věž/model zatím není samostatně doložené.
- Více modelů naslicovaných na **jedné podložce** je považováno za jeden tisk. Rozdělit jeho čas mezi jednotlivé modely by bez dalších údajů nebylo správné.
- Pokud načteš několik tisků, jejich časy se sčítají. Nejde o plánování souběžného tisku.
- U jednotlivého `.gcode` bez informací sliceru může být nutné hodnoty vyplnit ručně.
- PDF je tiskový rozpočet, **nikoliv daňová faktura**.

## Kontrola výpočtů

Samostatnou čtečku a výpočty lze otestovat bez PySide6:

```bash
python3 test_engine.py
```

Testy zahrnují výpočet ceny, katalog barev, ukládání zakázek, čtení archivů a obyčejný G-code.

**Poznámka k ověření:** Výpočetní část byla otestována na dodaném `Oci.gcode.3mf`. Grafické prostředí nebylo v prostředí tvorby možné přímo spustit kvůli nedostupnému PySide6, takže případné chyby zobrazení bude potřeba doladit při spuštění na MX Linuxu.
