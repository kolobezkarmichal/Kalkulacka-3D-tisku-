# 3D Kalkulačka P2S – verze 0.8.1

Samostatná desktopová aplikace v Pythonu / PySide6 pro MX Linux KDE.

## Oprava v0.8.1 – česká diakritika při ukládání zakázek

- **Opraven automatický název souboru:** při prvním uložení zakázky zůstávají české znaky a mezery, například `Dárek Aleš` → `Dárek Aleš.3dk.json` (dříve `D_rek_Ale_.3dk.json`).
- Neplatné znaky v názvu souboru (například `/`, `\`, `:`) se stále bezpečně nahrazují.
- Původní soubory `.3dk.json`, jejich obsah, výpočty a PDF export zůstávají beze změny.
- Oprava nemění jméno již dříve uložené zakázky při běžném opakovaném ukládání: pro nové jméno lze uložit nový soubor.
- Doplněny regresní testy pro české názvy, znaky s kombinovanou diakritikou a otevírání starších zakázek.

## Co se změnilo ve verzi 0.8

- **Náklady u každého tisku:** seznam „Tisky v zakázce“ ukazuje vedle sebe **Náklady**, **Cena** (výsledná prodejní cena) a **Rozdíl** (cena minus náklady) místo samotného sloupce Cena. Cena tedy **není** samotný zisk.
- **Výpočet za zadaný počet kusů:** všechny tři částky v řádku odpovídají počtu kusů dané položky, a navazují na souhrn zakázky nahoře. Náklady zahrnují filament, amortizaci, energii, práci a další zadané náklady.
- **Upozornění na ztrátu:** pokud je pevná cena nižší než náklady, zobrazí se záporný rozdíl barevně. Přejetím kurzoru nad finanční částku se zobrazí rozpis nákladů položky.
- **Export PDF a CSV:** částky Náklady, Cena a Rozdíl jsou vypsané také u jednotlivých tisků v exportech.
- **Zachované funkce:** předchozí motivy, výběr skladu, ochrana ovládání kolečkem a ukládané zakázky zůstávají kompatibilní.

## Co se změnilo ve verzi 0.7

- **Ochrana číselných polí před kolečkem:** otáčení kolečkem nad číslem (např. cena, koeficient, množství, amortizace) už hodnotu nezmění – ani když má pole fokus. Pokud je pole v posouvací oblasti, kolečko dál posouvá stránku. Číslo lze měnit kliknutím na šipky, napsáním hodnoty nebo klávesami nahoru/dolů.
- **Stejná ochrana výběrových polí:** kolečko nad zavřenou rozbalovací nabídkou nezmění zvolený materiál, režim výpočtu ani motiv. Po otevření nabídky je seznam možné rolovat obvyklým způsobem.
- **Beze změny výpočtů a dat:** staré zakázky, sklad i nastavení zůstávají kompatibilní.

## Co se změnilo ve verzi 0.6

- **HEX z webové evidence:** nové CSV obsahuje sloupec `HEX barva`; ten se načte jako přesná barva filamentu podle skladového ID. Přesný odstín má přednost před odhadem podle názvu a při příštím importu se aktualizuje. Pokud jsi barvu konkrétního tisku ručně přepsal, aplikace ji při obnově skladu nepřepíše.
- **Zpětná kompatibilita:** starší CSV bez HEX nadále funguje; ceny doplněné v kalkulačce se nepřepíší.

## Funkce zachované z verze 0.5

- **Přehledný výběr filamentu:** u každého filamentu načteného z G-code je místo dlouhé nabídky tlačítko s ID skladové položky. Kliknutím otevřeš zvláštní okno skladu.
- **Vyhledávání a filtrování:** v novém okně lze hledat podle ID, názvu/barvy, materiálu či výrobce i **bez diakritiky**. Výsledky lze filtrovat podle typu, výrobce a dostupné zásoby.
- **Automatické barvy podle názvu:** bez internetu a bez fotografií rozpoznává také odstíny „armádní zelená“, „olivová“, „tmavě modrá“, „světle růžová“, „pastelová“, „tyrkysová“, „stříbrná“, „bronzová“ a další. Odhad funguje i pro nově importované položky. Neznámá barva bude neutrálně šedá. Přesný ručně vyplněný HEX má vždy přednost. V tabulce je orientační odstín a vysvětlující popisek.
- **Zásoby:** v přehledu vidíš dostupné množství a přibližný zůstatek po aktuálním tisku. V detailu zakázky zůstává kontrola všech tisků a kusů dohromady.
- **Ceny:** po výběru položky podle ID se použije její uložená cena. Pokud žádnou nemá, použije se výchozí sazba a u výpočtu se zobrazí upozornění.
- **Údaj „Veřejný / Skrytý“ není v kalkulačce zobrazen:** v interních datech starších projektů může zůstat kvůli kompatibilitě, ale neovlivňuje výběr.
- **Ruční změna:** vedle tlačítka skladu je tlačítko `Typ…`, které dovolí změnit základní typ materiálu i bez skladu.

## Jak vybrat filament

1. V hlavním okně ponech/importuj CSV ze své evidence tlačítkem **Import skladu**.
2. Načti G-code a vyber tisk vlevo.
3. V tabulce filamentů klikni v prvním sloupci na **Vybrat ze skladu…**, případně na tlačítko s ID již zvoleného filamentu.
4. V novém okně filtruj seznam. Dvojklikem na řádek nebo tlačítkem **Použít vybraný filament** nastavíš konkrétní položku.
5. Program podle stabilního ID přiřadí materiál, název, cenu i skladovou zásobu. Zobrazovaný odstín bez zadaného HEX je pouze orientační.

## Propojení s webovou správou filamentů

Tato verze nadále pracuje s **lokálním importem CSV**. Dodané `filamenty.php` pouze přesměrovává na `index.php`, které podle přiloženého zdroje načítá data pomocí `id/core.php` a zobrazuje je přes `id/view.php`. V aktuální dodávce zdrojových souborů již byly získány a webový export HEX je implementován v samostatném balíčku. Odkaz `https://kick-print.borec.cz/filamenty/id/sprava.php` je stránka pro přihlášeného uživatele, nikoliv strojově čitelný zdroj dat. Zobrazení stránky v prohlížeči nezaručuje automatický přístup samostatnému Python programu.

Pro skutečné načítání bez exportu CSV bude potřeba doplnit **autentizované PHP rozhraní pouze pro čtení** (například `filamenty-api.php`) přímo do stávající webové aplikace. Mělo by vracet jen ID, název, typ, výrobce, aktuální množství, případné HEX/foto a datum změny. **Nebude** měnit sklad ani odpisovat materiál. K jeho doprogramování jsou potřeba zdrojové soubory evidenční aplikace a způsob jejího uložení dat, ne přihlašovací hesla.

## Instalace a aktualizace

1. Zálohuj si původní aplikaci a soubor `~/.config/3d-kalkulacka-p2s/settings.json`.
2. Rozbal ZIP a nahraď soubory aplikace novou verzí.
3. Složku `.venv` ponech – závislosti PySide6 není potřeba instalovat znovu.
4. Spusť `./spustit.sh`.

Při první instalaci:

```bash
sudo apt install python3-venv kdialog
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
./spustit.sh
```

## Testy a omezení

```bash
python3 test_engine.py
python3 test_inventory.py
python3 test_colors.py
python3 test_item_costs.py
python3 test_filenames.py
```

Oba testovací soubory prošly. **Grafické prostředí nebylo otestováno spuštěním**, protože testovací kontejner nemá dostupnou knihovnu PySide6 a její instalace není v tomto prostředí přístupná. Ověření klikání je tedy potřeba na cílovém Linuxu. Aplikace nedělá fyzické odpisy ze skladu.
